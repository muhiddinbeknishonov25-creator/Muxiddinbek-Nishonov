// 14-topshiriq: 1 dan 50 gacha bo'lgan 3 ga karrali sonlarni chiqaring

for (let i = 1; i <= 50; i++) {
    if (i % 3 === 0) {
        console.log(i);
    }
}
