// 12-topshiriq: 1 dan N gacha bo'lgan sonlar ko'paytmasini hisoblang

let n = Number(prompt("N ni kiriting:"));
let kopaytma = 1;

for (let i = 1; i <= n; i++) {
    kopaytma *= i;
}

alert("Ko'paytma = " + kopaytma);
