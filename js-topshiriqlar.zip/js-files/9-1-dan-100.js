// 9-topshiriq: 1 dan 100 gacha bo'lgan sonlarni ekranga chiqaring

for (let i = 1; i <= 100; i++) {
    console.log(i);
}
