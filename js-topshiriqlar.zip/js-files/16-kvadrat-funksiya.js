// 16-topshiriq: Sonning kvadratini qaytaruvchi funksiya

function kvadrat(n) {
    return n * n;
}

let son = Number(prompt("Sonni kiriting:"));

alert("Kvadrat = " + kvadrat(son));
