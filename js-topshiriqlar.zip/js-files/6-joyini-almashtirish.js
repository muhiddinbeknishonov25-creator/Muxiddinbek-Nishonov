// 6-topshiriq: Uchinchi o'zgaruvchisiz ikki sonning joyini almashtiring

let a = Number(prompt("1-sonni kiriting:"));
let b = Number(prompt("2-sonni kiriting:"));

console.log("Oldin: a = " + a + ", b = " + b);

a = a + b;
b = a - b;
a = a - b;

alert("Keyin: a = " + a + ", b = " + b);
