// 17-topshiriq: Berilgan sonning kubini qaytaruvchi funksiya

function kub(n) {
    return n * n * n;
}

let son = Number(prompt("Sonni kiriting:"));

alert("Kub = " + kub(son));
