// 15-topshiriq: Ikki sonning yig'indisini qaytaruvchi funksiya

function yigindi(a, b) {
    return a + b;
}

let son1 = Number(prompt("1-sonni kiriting:"));
let son2 = Number(prompt("2-sonni kiriting:"));

alert("Yig'indi = " + yigindi(son1, son2));
