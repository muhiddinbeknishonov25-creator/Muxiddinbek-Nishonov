// 10-topshiriq: 1 dan N gacha bo'lgan sonlar yig'indisini hisoblang

let n = Number(prompt("N ni kiriting:"));
let yigindi = 0;

for (let i = 1; i <= n; i++) {
    yigindi += i;
}

alert("Yig'indi = " + yigindi);
