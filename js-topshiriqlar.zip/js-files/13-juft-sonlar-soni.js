// 13-topshiriq: 1 dan N gacha bo'lgan juft sonlar sonini hisoblang

let n = Number(prompt("N ni kiriting:"));
let soni = 0;

for (let i = 1; i <= n; i++) {
    if (i % 2 === 0) soni++;
}

alert("Juft sonlar soni: " + soni);
