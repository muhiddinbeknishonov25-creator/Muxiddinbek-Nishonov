// 18-topshiriq: Massiv elementlari yig'indisini hisoblang

let arr = [1, 4, 8, 9, 10, 32, 22, 45];
let yigindi = 0;

for (let i = 0; i < arr.length; i++) {
    yigindi += arr[i];
}

console.log("Yig'indi = " + yigindi);
