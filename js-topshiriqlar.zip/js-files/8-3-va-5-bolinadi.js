// 8-topshiriq: Berilgan son 3 ga va 5 ga bo'linadimi?

let son = Number(prompt("Sonni kiriting:"));

if (son % 3 === 0 && son % 5 === 0) {
    alert(son + " — 3 ga ham, 5 ga ham bo'linadi");
} else if (son % 3 === 0) {
    alert(son + " — faqat 3 ga bo'linadi");
} else if (son % 5 === 0) {
    alert(son + " — faqat 5 ga bo'linadi");
} else {
    alert(son + " — na 3 ga, na 5 ga bo'linmaydi");
}
