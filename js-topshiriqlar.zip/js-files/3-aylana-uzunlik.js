// 3-topshiriq: Aylana radiusi berilgan. Aylananing uzunligini hisoblang

let radius = Number(prompt("Radiusni kiriting:"));

let uzunlik = 2 * Math.PI * radius;

alert("Aylana uzunligi = " + uzunlik.toFixed(2));
