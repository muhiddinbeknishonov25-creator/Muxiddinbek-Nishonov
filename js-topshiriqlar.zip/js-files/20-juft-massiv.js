// 20-topshiriq: Massivdagi juft elementlarni alohida massivga joylashtiring

let arr = [1, 4, 8, 9, 10, 32, 22, 45];
let juftlar = [];

for (let i = 0; i < arr.length; i++) {
    if (arr[i] % 2 === 0) {
        juftlar.push(arr[i]);
    }
}

console.log("Juft sonlar: " + juftlar);
