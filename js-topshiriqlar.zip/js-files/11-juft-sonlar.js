// 11-topshiriq: 1 dan 100 gacha bo'lgan juft sonlarni chiqaring

for (let i = 2; i <= 100; i += 2) {
    console.log(i);
}
