// 5-topshiriq: Berilgan son musbat, manfiy yoki nol ekanligini aniqlang

let son = Number(prompt("Sonni kiriting:"));

if (son > 0) {
    alert(son + " — musbat son");
} else if (son < 0) {
    alert(son + " — manfiy son");
} else {
    alert("Bu nol");
}
