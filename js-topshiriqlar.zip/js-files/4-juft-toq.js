// 4-topshiriq: Berilgan son juft yoki toq ekanligini aniqlang

let son = Number(prompt("Sonni kiriting:"));

if (son % 2 === 0) {
    alert(son + " — juft son");
} else {
    alert(son + " — toq son");
}
