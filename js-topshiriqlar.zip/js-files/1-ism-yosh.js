// 1-topshiriq: Foydalanuvchining ismi va yoshini ekranga chiqaring

let ism = prompt("Ismingizni kiriting:");
let yosh = prompt("Yoshingizni kiriting:");

alert("Ism: " + ism + ", Yosh: " + yosh);
