// 2-topshiriq: To'g'ri to'rtburchakning yuzasini hisoblang

let uzunlik = Number(prompt("Uzunlikni kiriting:"));
let en = Number(prompt("Enini kiriting:"));

let yuza = uzunlik * en;

alert("Yuza = " + yuza);
