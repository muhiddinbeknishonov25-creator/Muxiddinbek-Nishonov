// 7-topshiriq: Uchta son berilgan. Eng kattasini aniqlang

let a = Number(prompt("1-sonni kiriting:"));
let b = Number(prompt("2-sonni kiriting:"));
let c = Number(prompt("3-sonni kiriting:"));

let max = a;
if (b > max) max = b;
if (c > max) max = c;

alert("Eng katta son: " + max);
